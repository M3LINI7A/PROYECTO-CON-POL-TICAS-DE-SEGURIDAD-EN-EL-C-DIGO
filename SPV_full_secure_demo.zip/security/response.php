<?php
declare(strict_types=1);
function json_response(array $data, int $status=200): void { if(!headers_sent()){ header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0'); } http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function json_error(string $message, int $status=400, array $extra=[]): void { json_response(array_merge(['error'=>$message],$extra),$status); }