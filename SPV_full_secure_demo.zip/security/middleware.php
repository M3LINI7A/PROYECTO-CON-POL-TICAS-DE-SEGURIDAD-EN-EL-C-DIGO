<?php
declare(strict_types=1);
require_once __DIR__.'/csrf.php'; require_once __DIR__.'/auth.php'; require_once __DIR__.'/rate_limit.php'; require_once __DIR__.'/response.php';
function enforce_post_csrf(string $csrfKey): void {
  if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST'){ json_error('Método no permitido',405); }
  $key=$_POST['csrf_key']??null; $token=$_POST['csrf_token']??null;
  if(!csrf_validate($key,$token)||$key!==$csrfKey){ json_error('Token CSRF inválido',419); }
}
function enforce_login(?string $role=null): void { if(!is_logged_in()){ json_error('No autenticado',401);} if($role && !has_role($role)){ json_error('No autorizado',403);} }
function enforce_rate_limit(int $max,int $window): void { $ip=$_SERVER['REMOTE_ADDR']??'cli'; $route=$_SERVER['REQUEST_URI']??'unknown'; $key=$ip.'|'.$route; if(!rate_limit_check($key,$max,$window)){ json_error('Demasiadas solicitudes. Intente más tarde.',429);} }
