<?php
declare(strict_types=1);
function init_error_handling(string $logPath): void {
  $dir=dirname($logPath); if(!is_dir($dir)) @mkdir($dir,0775,true);
  ini_set('log_errors','1'); ini_set('error_log',$logPath); ini_set('display_errors','0'); error_reporting(E_ALL);
  set_exception_handler(function($e){ error_log('[EXCEPTION] '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine()); http_response_code(500); echo 'Ha ocurrido un error inesperado.'; exit; });
  set_error_handler(function($sev,$msg,$file,$line){ if(!(error_reporting()&$sev)) return false; error_log('[ERROR] '.$msg.' in '.$file.':'.$line); http_response_code(500); echo 'Ha ocurrido un error inesperado.'; return true; });
}