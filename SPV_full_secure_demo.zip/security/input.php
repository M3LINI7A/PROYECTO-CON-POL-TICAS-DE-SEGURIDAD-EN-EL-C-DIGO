<?php
declare(strict_types=1);
function sanitize_string(?string $v): string { $s=$v??''; $s=strip_tags($s); $s=preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u','',$s); return trim($s); }
function sanitize_email(?string $v): string { return strtolower(trim(filter_var($v??'', FILTER_SANITIZE_EMAIL))); }
function validate_email(string $email): bool { return (bool)filter_var($email, FILTER_VALIDATE_EMAIL); }
function validate_password_strength(string $pwd): bool { if(strlen($pwd)<8) return false; if(!preg_match('/[A-Z]/',$pwd)) return false; if(!preg_match('/[a-z]/',$pwd)) return false; if(!preg_match('/\d/',$pwd)) return false; if(!preg_match('/[^a-zA-Z\d]/',$pwd)) return false; return true; }
function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }