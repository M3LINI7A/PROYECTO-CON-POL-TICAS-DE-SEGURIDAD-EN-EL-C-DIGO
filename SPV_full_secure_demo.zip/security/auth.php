<?php
declare(strict_types=1);
require_once __DIR__.'/session.php'; require_once __DIR__.'/input.php';
function register_user(PDO $pdo, string $email, string $password, string $role='USER'): int {
  $email=sanitize_email($email); if(!validate_email($email)) throw new InvalidArgumentException('Email inválido.');
  if(!validate_password_strength($password)) throw new InvalidArgumentException('La contraseña no cumple con la política.');
  $hash=password_hash($password, PASSWORD_DEFAULT);
  $stmt=$pdo->prepare('INSERT INTO users (email,password_hash,role,created_at) VALUES (:email,:hash,:role,:created_at)');
  $ok=$stmt->execute([':email'=>$email,':hash'=>$hash,':role'=>$role,':created_at'=>date('c')]);
  if(!$ok){$err=$stmt->errorInfo(); throw new RuntimeException('No se pudo registrar: '.($err[2]??'error'));}
  return (int)$pdo->lastInsertId();
}
function authenticate(PDO $pdo, string $email, string $password): bool {
  secure_session_start(); $email=sanitize_email($email);
  $stmt=$pdo->prepare('SELECT id,email,password_hash,role FROM users WHERE email=:email LIMIT 1'); $stmt->execute([':email'=>$email]); $u=$stmt->fetch(PDO::FETCH_ASSOC);
  if(!$u || !password_verify($password,(string)$u['password_hash'])) return false;
  if(password_needs_rehash((string)$u['password_hash'], PASSWORD_DEFAULT)){ $new=password_hash($password,PASSWORD_DEFAULT); $upd=$pdo->prepare('UPDATE users SET password_hash=:h WHERE id=:id'); $upd->execute([':h'=>$new,':id'=>$u['id']]); }
  session_regenerate_id(true);
  $_SESSION['user']=['id'=>(int)$u['id'],'email'=>$u['email'],'role'=>$u['role'],'login_at'=>time()];
  return true;
}
function is_logged_in(): bool { return isset($_SESSION['user']['id']); }
function require_auth(?string $role=null): void { if(!is_logged_in()){ http_response_code(401); die('No autenticado.'); } if($role!==null && !has_role($role)){ http_response_code(403); die('No autorizado.'); } }
function has_role(string $role): bool { return isset($_SESSION['user']['role']) && strtoupper($_SESSION['user']['role'])===strtoupper($role); }
function current_user(): ?array { return $_SESSION['user']??null; }
function logout(): void { logout_and_destroy(); }