<?php
declare(strict_types=1);
function secure_session_start(string $name='SPVSESSID', int $idle_timeout=1200, int $regen_every=300): void {
  if (session_status()===PHP_SESSION_ACTIVE) return;
  ini_set('session.use_strict_mode','1');
  ini_set('session.use_only_cookies','1');
  ini_set('session.cookie_httponly','1');
  ini_set('session.cookie_samesite','Strict');
  session_name($name);
  session_set_cookie_params(['lifetime'=>0,'path'=>'/','domain'=>'','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','httponly'=>true,'samesite'=>'Strict',]);
  session_start();
  $now=time();
  $_SESSION['__created']=$_SESSION['__created']??$now;
  $_SESSION['__last_activity']=$_SESSION['__last_activity']??$now;
  $_SESSION['__last_regen']=$_SESSION['__last_regen']??$now;
  if (($now-$_SESSION['__last_activity'])>$idle_timeout) { session_unset(); session_destroy(); session_write_close(); return; }
  $_SESSION['__last_activity']=$now;
  if (($now-$_SESSION['__last_regen'])>$regen_every) { session_regenerate_id(true); $_SESSION['__last_regen']=$now; }
}
function logout_and_destroy(): void {
  if (session_status()===PHP_SESSION_ACTIVE) { $_SESSION=[]; if (ini_get('session.use_cookies')) { $p=session_get_cookie_params(); setcookie(session_name(),'',
    time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']); } session_destroy(); }
}