<?php
declare(strict_types=1);
function rate_limit_check(string $key, int $max, int $window): bool {
  $dir=sys_get_temp_dir().DIRECTORY_SEPARATOR.'spv_rate_limit'; if(!is_dir($dir)) @mkdir($dir,0775,true);
  $file=$dir.DIRECTORY_SEPARATOR.sha1($key).'.json'; $now=time(); $data=['count'=>0,'reset_at'=>$now+$window];
  if(file_exists($file)){ $raw=file_get_contents($file); if($raw!==false){ $data=json_decode($raw,true)?:$data; } if($now>($data['reset_at']??0)){ $data=['count'=>0,'reset_at'=>$now+$window]; } }
  if($data['count']>= $max) return false; $data['count']++; file_put_contents($file,json_encode($data),LOCK_EX); return true;
}