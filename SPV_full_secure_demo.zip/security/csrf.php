<?php
declare(strict_types=1);
function csrf_token(string $key='default'): string { if(!isset($_SESSION['csrf'])) $_SESSION['csrf']=[]; $t=bin2hex(random_bytes(32)); $_SESSION['csrf'][$key]=$t; return $t; }
function csrf_field(string $key='default'): string { $t=csrf_token($key); return '<input type="hidden" name="csrf_token" value="'.htmlspecialchars($t,ENT_QUOTES,'UTF-8').'">'.
'<input type="hidden" name="csrf_key" value="'.htmlspecialchars($key,ENT_QUOTES,'UTF-8').'">'; }
function csrf_validate(?string $key, ?string $token): bool { if(!$key||!$token) return false; if(!isset($_SESSION['csrf'][$key])) return false; $ok=hash_equals($_SESSION['csrf'][$key],$token); unset($_SESSION['csrf'][$key]); return $ok; }