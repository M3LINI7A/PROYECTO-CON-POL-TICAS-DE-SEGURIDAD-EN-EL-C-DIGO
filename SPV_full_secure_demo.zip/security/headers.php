<?php
declare(strict_types=1);
if (!headers_sent()) {
  header('X-Content-Type-Options: nosniff');
  header('X-Frame-Options: DENY');
  header('Referrer-Policy: no-referrer');
  header('Cross-Origin-Opener-Policy: same-origin');
  header('Cross-Origin-Resource-Policy: same-origin');
  header('Permissions-Policy: geolocation=(), microphone=(), camera=(), accelerometer=(), magnetometer=(), gyroscope=(), payment=()');
  $csp=["default-src 'self'","base-uri 'self'","frame-ancestors 'none'","form-action 'self'","img-src 'self' data:","style-src 'self' 'unsafe-inline'","script-src 'self'","font-src 'self' data:","connect-src 'self' ws: wss:"];
  header('Content-Security-Policy: '.implode('; ',$csp));
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') || ((int)($_SERVER['SERVER_PORT']??0)===443);
  if ($https) { header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload'); ini_set('session.cookie_secure','1'); }
}