<?php
declare(strict_types=1);

$root = dirname(__DIR__);
require $root . '/security/errors.php';
init_error_handling($root . '/security/logs/php-error.log');

$dsn = 'sqlite:' . $root . '/spv.sqlite';
$pdo = new PDO($dsn);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pdo->exec('CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT "USER",
  created_at TEXT NOT NULL
)');

$email = $argv[1] ?? 'admin@example.com';
$pass  = $argv[2] ?? 'Admin123!';
$role  = $argv[3] ?? 'ADMIN';

$exists = $pdo->prepare('SELECT id FROM users WHERE email = :email');
$exists->execute([':email' => $email]);
$row = $exists->fetch(PDO::FETCH_ASSOC);

if ($row) {
  echo "Usuario ya existe: {$email}\n";
  exit(0);
}

$hash = password_hash($pass, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO users (email, password_hash, role, created_at) VALUES (:e, :h, :r, :c)');
$stmt->execute([':e'=>$email, ':h'=>$hash, ':r'=>$role, ':c'=>date('c')]);
echo "Usuario creado: {$email} (rol {$role})\n";
