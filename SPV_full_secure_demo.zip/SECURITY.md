# SECURITY.md — SPV
(Resumen, riesgos OWASP, controles, configuración, límites y evidencias según versión anterior)
