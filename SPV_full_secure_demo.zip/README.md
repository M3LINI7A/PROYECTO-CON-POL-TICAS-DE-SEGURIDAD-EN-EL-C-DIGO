

## Demo rápida con servidor embebido de PHP
1) Inicializa la base SQLite y crea un admin:
```bash
php scripts/init_sqlite.php admin@example.com Admin123! ADMIN
```
2) Servir la carpeta `public/`:
```bash
php -S localhost:8000 -t public
```
3) Navegar:
- `http://localhost:8000/`
- `http://localhost:8000/login.php`
- `http://localhost:8000/api/me.php`
- `http://localhost:8000/logout.php`
