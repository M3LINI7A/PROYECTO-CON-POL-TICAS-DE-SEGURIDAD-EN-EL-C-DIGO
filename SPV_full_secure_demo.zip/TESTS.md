# TESTS.md — Pruebas de Seguridad
(Procedimientos: sesiones, RBAC, CSRF, rate-limit, SQLi, XSS, cabeceras, logs, curl de ejemplo)
