<?php
	/*===========================================
	|  Datos del servidor - Data of the server  |
	===========================================*/
	const SERVER="localhost";
	const DB="spv";
	const USER='root';
	const PASS="";

	
	
	const SGBD="mysql:host=".SERVER.";dbname=".DB;


	/*===========================================
	| Datos de la encriptacion - Encryption data |
	===========================================*/
	const METHOD='AES-256-CBC';
	const SECRET_KEY='$SPV@2024';
	const SECRET_IV='179120';