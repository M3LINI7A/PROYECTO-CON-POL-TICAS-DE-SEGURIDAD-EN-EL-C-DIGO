<?php
	const SERVERURL = "http://localhost/SPV/";

	const COMPANY = "UNIVALLE";

	/*====================================
	=            Zona horaria            =
	====================================*/
	date_default_timezone_set("America/El_Salvador");

	/**
		Zonas horarias:
		- America/El_Salvador
		- America/Costa_Rica
		- America/Guatemala
		- America/Puerto_Rico
		- America/Panama
		- Europe/Madrid

		Más zonas, visita http://php.net/manual/es/timezones.php

	/*=====  End of Zona horaria  ======*/