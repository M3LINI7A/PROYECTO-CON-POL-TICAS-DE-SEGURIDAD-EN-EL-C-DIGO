<div class="page-header">
	<h1 class="text-titles"><i class="zmdi zmdi-store zmdi-hc-fw"></i> Bienvenido a <small><?php echo COMPANY; ?></small></h1>
</div>
<div class="full-box" style="margin-bottom: 20px;">
	<img src="<?php echo SERVERURL; ?>views/assets/img/banner.png" alt="<?php echo COMPANY; ?>" class="img-responsive" style="margin:0 auto;">
</div>