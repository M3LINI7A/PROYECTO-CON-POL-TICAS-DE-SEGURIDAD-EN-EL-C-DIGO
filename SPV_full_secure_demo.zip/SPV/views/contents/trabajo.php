    <h4>IP: <span id="ip">0 </span></h4>
	
<style> .form-group { max-width: 250px; /* Ajusta el ancho máximo de los campos */ 
    margin-right: 10px; /* Espacio entre los campos */ } </style>
    <div class="container"> <div class="form-row"> <div class="form-group col-md-4 label-floating"> <label class="control-label" for="sistole">SISTOLE</label> <input class="form-control" id="sistole" type="text" name="sistole"> <p class="help-block">Ingresa Sistole</p> </div> <div class="form-group col-md-4 label-floating"> <label class="control-label" for="diastole">DIASTOLE</label> <input class="form-control" id="diastole" type="text" name="diastole"> <p class="help-block">Ingresa Diastole</p> </div> <div class="form-group col-md-4 label-floating"> <label class="control-label" for="fc">F.C</label> <input class="form-control" id="fc" type="text" name="fc"> <p class="help-block">Ingresa Frecuencia Cardiaca</p> </div> </div> </div>
	<button id="simular" onclick="toggle()" disabled>INICIAR</button>
    <button id="actualizar" onclick="toggle1()">ACTUALIZA</button>
    <button id="configurar" onclick="configurar()" disabled>ENVIAR</button>
    <button id="osci" onclick="osci()" disabled>VER OSCILOMETRICA</button>
    <button id="CSV" onclick="CSV()" disabled>Guardar CSV</button>

    <div class="container">
         <div class="form-row"> 
            <div class="form-group col-md-4 label-floating">
                <label class="control-label" for="PP">PRESION PRUEBA</label>
                <input class="form-control" id="presion" type="text" name="presion">
                <p class="help-block">Ingresa PRESION DE PRUEBA DE FUGAS</p> 
            </div>
         </div>
         
    </div>
    <button id="fuga" onclick="fuga()" disabled>PRUEBA DE FUGAS</button>
    <div class="timer" id="timer">02:00</div> 
    <style>
     #progressBar { width: 100%; background-color: #f3f3f3; } #progress { width: 0%; height: 30px; background-color: #4caf50; text-align: center; line-height: 30px; color: white;
    display: none; }
      </style>
     
    <div class="container" id = "pp2" style="display: none" > 
        <h1>PRUEBA DE FUGAS</h1>
         <div id="progressBar">
             <div id="progress">0%</div>
             </div>
              <h4>Valores Recibidos:</h4>
              <div id="values"><label id="valueLabel"></label></div>
             </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style> #chartContainer { display: none; /* Ocultar el contenedor del gráfico inicialmente */ } </style>


 <div id="chartContainer"> <canvas id="myChart"></canvas> </div> 

 <div style="width: 80%; margin: auto;"> <canvas id="oscillometricChart" style="display: none" ></canvas> </div>
 <style> .timer { font-size: 48px; text-align: center; margin-top: 2%; display: none; } </style>
 

 <script> // Tiempo inicial en segundos (2 minutos)
  var timeLeft = 2 * 60;
   var timerInterval;
   var una=0; 
   function startTimer()
    {
        if(una==0)
        {
        document.getElementById("timer").style.display = "block";
        timerInterval = setInterval(updateTimer, 1000);
        }
        //socket.send("3:"+document.getElementById("presion").value+":0:0.");
        
    }
    function vertTimer()
    {
        document.getElementById("timer").style.display = "block";
           
    } 
    function updateTimer() 
    {
         var minutes = Math.floor(timeLeft / 60); var seconds = timeLeft % 60; // Formatear minutos y segundos con dos dígitos 
         minutes = minutes < 10 ? '0' + minutes : minutes;
          seconds = seconds < 10 ? '0' + seconds : seconds;
           // Actualizar el elemento del cronómetro 
           document.getElementById('timer').innerHTML = minutes + ':' + seconds; 
           // Reducir el tiempo en 1 segundo 
           timeLeft--; // Detener el cronómetro cuando llegue a 0 
           
           if (una==0 && timeLeft < 0) { 
            una=1;
            socket.send("4:200:1:1.");
            clearInterval(timerInterval); 
            document.getElementById('timer').innerHTML = '00:00'; 
            document.getElementById("timer").style.display = "none";
            let presionValue = Number(document.getElementById("presion").value);
            var valueLabel = document.getElementById("valueLabel"); 
            var value = valueLabel.textContent;
            let presionValue1 = Number(value);
            
            if (((presionValue-presionValue1)/presionValue)>0.05)
            {
                alert("FUGA DETECTADA MAYOR 5%");
           socket.send("2:120:80:60.");
            }
            else
            {
                alert("NO HAY FUGA CONSIDERABLE");
            socket.send("2:120:80:60.");    
            }
            socket.send("2:120:80:60.");
            
        }
     }
      // Añadir evento al botón con id "fuga" para iniciar el cronómetro
      //document.getElementById('fuga').addEventListener('click', startTimer); 
      </script>
    <script>
		//REPLACE WITH YOUR COMPUTER IP ADDRESS WHERE THE WEBSOCKET SERVER IS RUNNING
        // codigos
        // socket.send("p1:p2:p3:p4.");
        // p1 = 1 actualizar estado 
        /**p1 = 1 actualizar estado  verificar que haya conectado ESP con simulador
         * p1 = 2 configurar parametros envia sistole, diastole y Fc
         *      p2 = sistole
         *      p3 = diastole
         *      p4 = Fc
        */

       


		var socket = new WebSocket('ws://192.168.179.13:8181');
		let valoresRecepcionados = [];
         var ctx = document.getElementById('myChart').getContext('2d');
          var myChart = new Chart(ctx, { type: 'line', data: { labels: [], 
            // Etiquetas iniciales vacías
             datasets: [{ label: 'Valores Recepcionados', data: [], // Datos iniciales vacíos 
                borderColor: 'rgba(75, 192, 192, 1)', borderWidth: 2, fill: false }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: true, } }, scales: { y: { beginAtZero: true } } } });

		socket.onmessage = function(event) { 
			//console.log(event.data);
            const data = event.data.split(":");//event.data.split(":");
            const msg = data[0] || ""; // Mensaje recibido
            const param = data[1] || ""; // Parámetro recibido
            console.log(msg);
            console.log(param);
            console.log(data);
            if(param == "s1.\r"){ 
                
                valoresRecepcionados.push(Number(msg));
                myChart.data.labels = valoresRecepcionados.map((_, index) => index + 1); 
                myChart.data.datasets[0].data = valoresRecepcionados; 
                myChart.update();
                
                
			}
			else if(param == "p1."){ 
				var ip =msg;
				
				document.getElementById("ip").innerHTML = ip ;
                document.getElementById("configurar").disabled = false;
                document.getElementById("osci").disabled = false;
                document.getElementById("fuga").disabled = false;
                
				
			}
            else if(param == "p2."){ 
				var parts = msg.split(",");
				var ip = parts[0];
				var config = parts[1];
				
				document.getElementById("ip").innerHTML = ip ;
				
			}
            else if(param =="termino.")
            {
                document.getElementById("simular").disabled = false;
                document.getElementById("fuga").disabled = false;
            }
            else if(param == "s2.\r"){ 
				
                
                updateProgressBar(Number(msg)); 
                displayValues(Number(msg));
                let presionValue = Number(document.getElementById("presion").value);
    
    if (msg >= presionValue) {
        startTimer(); 
    }
                
			}
		};
    	
        function updateProgressBar(value)
         { 
            var progressBar = document.getElementById("progress"); 
            var maxPressure = parseInt(document.getElementById("presion").value); 
            var progressValue = Math.min(parseInt(value), maxPressure); 
            // Asegura que el valor no exceda el máximo 
            var percentWidth = (progressValue / maxPressure) * 100; 
            // Calcula el ancho en porcentaje 
            progressBar.style.width = percentWidth + '%'; 
            progressBar.innerHTML = progressValue;
         }
         function displayValues(value) { 
            var valueLabel = document.getElementById("valueLabel"); 
            valueLabel.textContent = value;
            
        }
		function toggle() { 
           socket.send("13:0:0:0.");
           document.getElementById("chartContainer").style.display = "block";
           myChart.data.labels = []; 
           myChart.data.datasets[0].data = []; 
           myChart.update();
           document.getElementById("simular").disabled = true;
           document.getElementById("CSV").disabled = false;
		
		}
        function toggle1() { 
			socket.send("1:0:0:0.");
		}
        function fuga() { 
            socket.send("3:"+document.getElementById("presion").value+":0:0.");
            
            document.getElementById("pp2").style.display = "block";
            document.getElementById("progress").style.display = "block";
            socket.send("3:"+document.getElementById("presion").value+":0:0.");
            document.getElementById("fuga").disabled =true;
		}
        function configurar() { 
            var p1 = document.getElementById("sistole").value;
            var p2 = document.getElementById("diastole").value;
            var p3 = document.getElementById("fc").value;
			socket.send("2:"+p1+":"+p2+":"+p3+".");
            document.getElementById("simular").disabled = false;
		}

        function CSV() { 
            
               // Función para generar el archivo CSV 
               
               generarCSV();
		}
        function generarCSV(){
            var fileName = "<?php echo $rows['id']; ?>_" + "<?php echo $_SESSION['userKey']; ?>.csv";
             document.getElementById("ip").innerHTML = fileName; 
             // Contenido del array valoresRecepcionados
             
             var csvContent = "data:text/csv;charset=utf-8,";
                 valoresRecepcionados.forEach(function(valor) 
                 { csvContent += valor + "\r\n";

                  });
                   var encodedUri = encodeURI(csvContent); 
                   var link = document.createElement("a");
                    link.setAttribute("href", encodedUri); 
                    link.setAttribute("download", fileName);
                     document.body.appendChild(link);
                      link.click(); 
                    }

                    function findPeaks(data, minDuration = 1, maxDuration = 3) {
                         let peaks = []; let i = 0; while (i < data.length) {
                             let isPeak = false; 
                             let peakStart = i; 
                             let peakValue = data[i]; 
                             // Detectar un pico 
                             while (i < data.length && data[i] >= peakValue - 1 && data[i] <= peakValue + 1) { peakValue = data[i]; i++; } let peakEnd = i - 1; 
                             // Verificar duración del pico 
                             if (peakEnd - peakStart + 1 >= minDuration && peakEnd - peakStart + 1 <= maxDuration) 
                             { // Verificar si es pico válido (descenso después del pico) 
                                if (i < data.length && data[i] < peakValue) 
                                {
                                     for (let j = peakStart; j <= peakEnd; j++)
                                      { peaks.push({ index: j, value: data[j] }); } } }
                                       // Continuar al siguiente punto
                                        i = peakEnd + 1; } return peaks; }
 function findPeaks1(data, pdiast, pmedia, psist) {
    let series = [];
    let valoresPermitidos = false; // Control para detectar si ya superó los límites

    for (let i = 0; i < data.length; i++) {
        // Si aún no ha superado pdiast ni psist, llena con 0
        if (!valoresPermitidos) {
            series.push({ index: i, value: 0 });

            // Activar registro cuando supere pdiast o psist
            if (data[i] > psist ) {
                valoresPermitidos = true;
            }
        } else {
            // Registrar valores dentro del rango permitido
            if (data[i] >= pdiast && data[i] <= psist) {
                series.push({ index: i, value: data[i] });
            } else {
                series.push({ index: i, value: 0 });
            }
        }
    }

    return series;
}


function generatePeaks(pdiast, pmedia, psist, numPoints = 100) {
    let peaks = [];
    let halfPoints = Math.floor(numPoints / 2);

    // Crecimiento exponencial desde pdiast hasta pmedia
    for (let i = 0; i < halfPoints; i++) {
        let factor = Math.exp(i / halfPoints - 1);
        let value = pdiast + (pmedia - pdiast) * factor;
        peaks.push({ index: i, value: value });
    }

    // Descenso exponencial desde pmedia hasta psist
    for (let i = halfPoints; i < numPoints; i++) {
        let factor = Math.exp(1 - (i - halfPoints) / halfPoints);
        let value = psist + (pmedia - psist) * factor;
        peaks.push({ index: i, value: value });
    }

    return peaks;
}
                    function osci() {
                        
                        var psist = Number(document.getElementById("sistole").value);
var pdiast = Number(document.getElementById("diastole").value);
var pmedia = ((2 * pdiast) + psist) / 3;
const peaks = findPeaks1(valoresRecepcionados,pdiast, pmedia, psist);

            console.log("pdiast: "+pdiast);
            console.log("psist: "+psist);
            

            console.log("pmedia: "+pmedia);
              

    
                        const verticalBars = generateVerticalBars(peaks, valoresRecepcionados.length);
                        //const peakValues = peaks.map(peak => peak.value);
                        const labels = valoresRecepcionados.map((_, index) => index + 1); 
                        const data = {
                             labels: labels, 
                             datasets: [ 
                                { label: 'Curva Oscilométrica',
                                     data: valoresRecepcionados, 
                                     borderColor: 'rgba(75, 192, 192, 0.5)', // Línea transparente 
                                     backgroundColor: 'rgba(75, 192, 192, 0.1)', // Relleno transparente 
                                     borderWidth: 2, fill: true
                                     },
                                      { 
                                        label: 'Picos', 
                                        data: peaks.map(peak => ({ x: peak.index + 1, y: peak.value })),
                                        borderColor: 'rgba(255, 0, 0, 1)',
                                         borderWidth: 2,
                                          pointRadius: 5,
                                           pointBackgroundColor: 'rgba(255, 0, 0, 1)', 
                                           backgroundColor: 'rgba(255, 0, 0, 0.3)', 
                                           // Color de relleno 
                                           fill: true, // Rellenar debajo de los puntos 
                                           showLine: false,
                                            pointShadowColor: 'rgba(255, 0, 0, 0.5)', 
                                            // Sombra de los puntos 
                                            pointShadowBlur: 10,
                                             pointShadowOffsetX: 0, 
                                             pointShadowOffsetY: 5
                                     },
                                     {
                                         label: 'Barras Verticales', 
                                        data: verticalBars.map(bar => ({ x: bar.index + 1, y: bar.value })),
                                        type: 'bar',
                                        // Tipo de gráfico de barras 
                                         backgroundColor: 'rgba(0, 0, 255, 0.2)',
                               // Color de las barras con transparencia
                                borderColor: 'rgba(0, 0, 255, 1)',
                                 // Color del borde de las barras 
                                 borderWidth: 1, fill: true 
                                 // Rellenar las barras
                                     }
                                 ]
                             };
                             // Configuración del gráfico
                              const config = { type: 'line',
                                 data: data,
                                  options:
                                   { responsive: true,
                                     scales: { 
                                        x: { title: { display: true, text: 'Tiempo (s)' } }, 
                                        y: { title: { display: true, text: 'Presión (mmHg)' } } },
                                         plugins: { legend: { display: true } } } };
                                          // Crear el gráfico 
                                          document.getElementById('oscillometricChart').style.display = "block";
                                          const ctx = document.getElementById('oscillometricChart').getContext('2d'); const oscillometricChart = new Chart(ctx, config);
                                            
                    }
                    function generateVerticalBars(peaks, dataLength) {
    let bars = new Array(dataLength).fill({ index: 0, value: 0 }); // Inicializar array con valores 0

    if (peaks.length > 0) {
        let firstPeak = peaks.find(peak => peak.value !== 0)?.index || 0;
        let lastPeak = [...peaks].reverse().find(peak => peak.value !== 0)?.index || dataLength - 1;
        let midPoint = firstPeak + Math.floor((lastPeak - firstPeak) * 0.7);

        for (let i = firstPeak; i <= midPoint; i++) {
            if (peaks[i]?.value !== 0) {
                let value = Math.pow(2, (i - firstPeak) / (midPoint - firstPeak)) * 40;
                bars[i] = { index: i, value: value };
            }
        }

        for (let i = midPoint + 1; i <= lastPeak; i++) {
            if (peaks[i]?.value !== 0) {
                let value = Math.pow(2, (lastPeak - i) / (lastPeak - midPoint)) * 40;
                bars[i] = { index: i, value: value };
            }
        }
    }

    return bars;
}

                    function generateVerticalBars1(peaks, dataLength) 
                    {
                         let bars = [];
                          if (peaks.length > 0) {
                             let firstPeak = peaks[0].index; 
                             let lastPeak = peaks[peaks.length - 1].index; 
                           //  let midPoint = Math.floor((firstPeak + lastPeak) / 2); 
                             let midPoint = firstPeak + Math.floor((lastPeak - firstPeak) * 0.3);
                        // Incrementar exponencialmente hasta el punto medio 
                       
                        for (let i = firstPeak; i <= midPoint; i++)
                         { 
                            let value = Math.pow(2, (i - firstPeak) / (midPoint - firstPeak)); 
                            value = value *40;
                            bars.push({ index: i, value: value }); 
                        } 
                        // Disminuir exponencialmente desde el punto medio hasta el último pico 
                        for (let i = midPoint + 1; i <= lastPeak; i++) { 
                            let value = Math.pow(2, (lastPeak - i) / (lastPeak - midPoint)); 
                            value=value*40;
                            bars.push({ index: i, value: value }); 
                        }
                     }
                      return bars; }

	</script>
    
    
   
  