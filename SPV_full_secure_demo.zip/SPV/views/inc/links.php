<title><?php echo COMPANY; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<link rel="stylesheet" href="<?php echo SERVERURL; ?>views/css/main.css">
<script src="<?php echo SERVERURL; ?>views/js/sweetalert2.min.js"></script>