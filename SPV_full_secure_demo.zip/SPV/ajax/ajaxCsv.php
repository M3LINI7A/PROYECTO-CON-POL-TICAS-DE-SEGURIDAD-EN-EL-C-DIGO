<?php
	$actionsRequired=true;
	require_once "../controllers/csvController.php";

	$insCsv = new csvController();

	$dateNow=date("Y-m-d");

	if(isset($_POST['csv']) && isset($_POST['codeUser'])){
		echo $insCsv->add_csv_controller();
	}