<?php
require 'vendor/autoload.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class MyWebSocket implements MessageComponentInterface { 
	public $clients;
	private $connectedClients;
	
    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->connectedClients = []; //conexion cliente
    }
	
	public function onOpen(ConnectionInterface $conn) { 
		$this->clients->attach($conn);
		$this->connectedClients[$conn->resourceId] = $conn;
		echo "New connection! ({$conn->resourceId})\n";
		$conn->send("Welcome to the Server.");
	}
	
	public function onMessage(ConnectionInterface $from, $msg) { 
		echo $msg . "\n";
		foreach ($this->connectedClients as $client) { 
			$client->send($msg);  //mensaje del cliente esp32 
		}
	}
	

	public function onClose(ConnectionInterface $conn) { 
		// Detatch everything from everywhere
        $this->clients->detach($conn);
        unset($this->connectedClients[$conn->resourceId]);
	}
	
	public function onError(ConnectionInterface $conn, \Exception $e) { 
		echo "An error occurred: " . $e->getMessage() . "\n";
		$conn->close();
	}
}

//REPLACE WITH YOUR COMPUTER IP ADDRESS WHERE THE WEBSOCKET SERVER IS RUNNING
$app = new Ratchet\App("192.168.179.13", 8181, "0.0.0.0");
$app->route('/', new MyWebSocket, array('*'));

$app->run(); // Arranca el servidor y empieza a escuchar conexiones entrantes.
?>