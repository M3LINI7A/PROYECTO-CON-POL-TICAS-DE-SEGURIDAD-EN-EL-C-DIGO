<!DOCTYPE html> 
<html> 
    <head>
         <title>PRUEBAS FUNCIONALES</title>
          <style> .modal {
                display: block; /* Mostrar por defecto */
                position: auto;
                z-index: 999;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                overflow: auto;
                background-color: rgb(0,0,0);
                background-color: transparent;
                } 
                .modal-content 
                {
                background-color: transparent;
                margin:  auto;
                padding: 20px;
                border: 1px solid #888;
                width: auto; 
                max-width: 500px;
                }
                .close-button
                {
                background-color: #4CAF50;
                color: white; 
                border: none; 
                padding: 15px 20px;
                text-align: center; 
                text-decoration: none; 
                display: inline-block; 
                font-size: 16px; 
                cursor: pointer; 
                display: flex;
                justify-content: center;
                } 
                .menu 
                {
                    font-family: Arial, sans-serif; 
                    width: 70%; margin: auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); } .menu h2 { text-align: center; } .option { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; } .option button { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; } .on { background-color: #4CAF50; color: white; } .off { background-color: #f44336; color: white; }
                </style>
        </head>
    <body>

    <div class="menu">
        <h2>OPCIONES DE VERIFICACION</h2>
        <div class="option">
             <span>MOTOR COMPRESOR</span>
              <button id="motorOn" class="on" onclick="toggleMotor(true)">ENCENDIDO</button>
               <button id="motorOff" class="off" onclick="toggleMotor(false)">APAGADO</button>
        </div>
        
        <div class="option">
                <span>MOTOR PASOS (REALIZA MOVIMIENTO ida y vuelta de forma continua)</span>
                <button id="sensorOn1" class="on" onclick="toggleSensor1(true)">ENCENDIDO</button> 
                <button id="sensorOff1" class="off" onclick="toggleSensor1(false)">APAGADO</button> 
        </div>
        
       
    </div>


         <div id="myModal" class="modal">
             <div class="modal-content"> 
                <span class="close-button" onclick="closeModal()">VOLVER</span>
             </div>
         </div>
        <script> 
        function closeModal() {
            window.history.back();
             }
        </script>

<script> 
function toggleMotor(isOn) {
    if (isOn) {
         document.getElementById('motorOn').style.display = 'none';
         document.getElementById('motorOff').style.display = 'inline-block';
         socket.send("5:0:0:0."); 
    } else { 
        document.getElementById('motorOn').style.display = 'inline-block'; 
        document.getElementById('motorOff').style.display = 'none'; 
        socket.send("6:0:0:0."); 
    } 
} 
function toggleSensor1(isOn) { 
    if (isOn) { document.getElementById('sensorOn1').style.display = 'none'; 
        document.getElementById('sensorOff1').style.display = 'inline-block';
        socket.send("7:0:0:0."); 
         
    } else { 
        document.getElementById('sensorOn1').style.display = 'inline-block'; 
        document.getElementById('sensorOff1').style.display = 'none'; 
        socket.send("8:0:0:0."); 
    } 
} 
function toggleSensor2(isOn) { 
    if (isOn) { document.getElementById('sensorOn2').style.display = 'none'; 
        document.getElementById('sensorOff2').style.display = 'inline-block'; 
    } else { 
        document.getElementById('sensorOn2').style.display = 'inline-block'; 
        document.getElementById('sensorOff2').style.display = 'none'; 
    } 
} 

function togglePasos(isOn) { 
    if (isOn) { document.getElementById('pasosOn').style.display = 'none'; 
        document.getElementById('pasosOff').style.display = 'inline-block'; 
    } else { 
        document.getElementById('pasosOn').style.display = 'inline-block'; 
        document.getElementById('pasosOff').style.display = 'none'; 
    } 
}
// Inicializar los botones en estado "apagado"
 toggleMotor(false); 
 toggleSensor1(false); 
 toggleSensor2(false); 
 togglePasos(false); 
 </script>


<script>
		//var socket = new WebSocket('ws://192.168.175.174:8181');
        var socket = new WebSocket('ws://192.168.179.13:8181');
		
		socket.onmessage = function(event) { 
			console.log(event.data);
			const data = event.data.split(":");
			
			const msg		= data[0] || "";
			const param	= data[1] || "";
			
			if(param == "G1"){ 
				
                valoresRecepcionados.push(Number(msg));
                myChart.data.labels = valoresRecepcionados.map((_, index) => index + 1); 
                myChart.data.datasets[0].data = valoresRecepcionados; 
                myChart.update();
                
                
			}
			else if(param == "p1"){ 
				var ip =msg;
				
				document.getElementById("ip").innerHTML = ip ;
                document.getElementById("configurar").disabled = false;
                document.getElementById("osci").disabled = false;
                document.getElementById("fuga").disabled = false;
                
				
			}
            else if(param == "p2"){ 
				var parts = msg.split(",");
				var ip = parts[0];
				var config = parts[1];
				
				document.getElementById("ip").innerHTML = ip ;
				
			}
            else if(param =="termino")
            {
                document.getElementById("simular").disabled = false;
                document.getElementById("fuga").disabled = false;
            }
            else if(param == "G2"){ 
				
               
                updateProgressBar(Number(msg)); displayValues(Number(msg));
                
                
			}
		};
    	
        

	</script>
    </body>
</html>