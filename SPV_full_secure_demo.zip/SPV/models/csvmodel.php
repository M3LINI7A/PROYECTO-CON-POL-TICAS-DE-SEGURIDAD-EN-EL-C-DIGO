<?php
	if($actionsRequired){
		require_once "../core/mainModel.php";
	}else{ 
		require_once "./core/mainModel.php";
	}

	class csvModel extends mainModel{

		/*----------  Add Comment Model  ----------*/
		public function add_csv_model($data){
			$query=self::connect()->prepare("INSERT INTO lectura(id,Adjunto,Tipo,Codigo,Fecha) VALUES(:id,:Adjunto,:Tipo,:Codigo,:Fecha)");
			$query->bindParam(":id",$data['id']);
			$query->bindParam(":Adjunto",$data['Adjunto']);
			$query->bindParam(":Tipo",$data['Tipo']);
			$query->bindParam(":Codigo",$data['Codigo']);
			$query->bindParam(":Fecha",$data['Fecha']);
			$query->execute();
			return $query;
		}


		/*----------  Delete Comment Model  ----------*/
		public function delete_csv_model($code){
			$query=self::connect()->prepare("DELETE FROM lectura WHERE idl=:idl");
			$query->bindParam(":idl",$code);
			$query->execute();
			return $query;
		}

	}