<!DOCTYPE html>
<html>
<head>
    <title>PRUEBAS FUNCIONALES</title>
    <style>
        .modal {
            display: block;
            position: auto;
            z-index: 999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: transparent;
        }

        .modal-content {
            background-color: transparent;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: auto;
            max-width: 500px;
        }

        .close-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 15px 20px;
            text-align: center;
            font-size: 16px;
            cursor: pointer;
            display: flex;
            justify-content: center;
        }

        .menu {
            font-family: Arial, sans-serif;
            width: 70%;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .menu h2 {
            text-align: center;
        }

        .option {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .option button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .on {
            background-color: #4CAF50;
            color: white;
        }

        .off {
            background-color: #f44336;
            color: white;
        }

        .input-group {
            margin: 20px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        input[type="number"] {
            width: 100px;
            padding: 10px;
            margin: 5px;
        }

        .center-btn {
            text-align: center;
            margin-top: 15px;
        }

    </style>
</head>
<body>

<div class="menu">
    <h2>OPCIONES DE VERIFICACIÓN</h2>

    <div class="input-group">
        <label>Sístole:</label>
        <input type="number" id="sistole" min="0" placeholder="mmHg">
        <label>Diástole:</label>
        <input type="number" id="diastole" min="0" placeholder="mmHg">
        <label>F.C.:</label>
        <input type="number" id="fc" min="0" placeholder="lpm">
    </div>

    <div class="center-btn">
        <button class="on" onclick="enviarDatos()">ENVIAR DATOS</button>
    </div>

    <hr>

    <div class="option">
        <span>MOTOR COMPRESOR</span>
        <button id="motorOn" class="on" onclick="toggleMotor(true)">ENCENDIDO</button>
        <button id="motorOff" class="off" onclick="toggleMotor(false)">APAGADO</button>
    </div>

    <div class="option">
        <span>SENSOR OSCILOMÉTRICO</span>
        <button id="sensorOn1" class="on" onclick="toggleSensor1(true)">ENCENDIDO</button>
        <button id="sensorOff1" class="off" onclick="toggleSensor1(false)">APAGADO</button>
    </div>

    <div class="option">
        <span>SENSOR FUGAS</span>
        <button id="sensorOn2" class="on" onclick="toggleSensor2(true)">ENCENDIDO</button>
        <button id="sensorOff2" class="off" onclick="toggleSensor2(false)">APAGADO</button>
    </div>

    <div class="option">
        <span>MOTOR PASOS</span>
        <button id="pasosOn" class="on" onclick="togglePasos(true)">ENCENDIDO</button>
        <button id="pasosOff" class="off" onclick="togglePasos(false)">APAGADO</button>
    </div>
</div>

<div id="myModal" class="modal">
    <div class="modal-content">
        <span class="close-button" onclick="closeModal()">VOLVER</span>
    </div>
</div>

<script>
    var socket = new WebSocket('ws://192.168.179.13:8181');
    

    function closeModal() {
        window.history.back();
    }

    function toggleMotor(isOn) {
        document.getElementById('motorOn').style.display = isOn ? 'none' : 'inline-block';
        document.getElementById('motorOff').style.display = isOn ? 'inline-block' : 'none';
        socket.send(isOn ? "5:0:0:0." : "6:0:0:0.");
    }

    function toggleSensor1(isOn) {
        document.getElementById('sensorOn1').style.display = isOn ? 'none' : 'inline-block';
        document.getElementById('sensorOff1').style.display = isOn ? 'inline-block' : 'none';
        //socket.send(isOn ? "SENSOR1:ON" : "SENSOR1:OFF");
    }

    function toggleSensor2(isOn) {
        document.getElementById('sensorOn2').style.display = isOn ? 'none' : 'inline-block';
        document.getElementById('sensorOff2').style.display = isOn ? 'inline-block' : 'none';
        //socket.send(isOn ? "SENSOR2:ON" : "SENSOR2:OFF");
    }

    function togglePasos(isOn) {
        document.getElementById('pasosOn').style.display = isOn ? 'none' : 'inline-block';
        document.getElementById('pasosOff').style.display = isOn ? 'inline-block' : 'none';
        socket.send(isOn ? "7:0:0:0." : "8:0:0:0.");
    }

    function enviarDatos() {
        let sistole = document.getElementById('sistole').value;
        let diastole = document.getElementById('diastole').value;
        let fc = document.getElementById('fc').value;

        if (sistole && diastole && fc) {
            let cadena = `${sistole},${diastole},${fc}:SEND`;
            socket.send(cadena);
            alert("Datos enviados: " + cadena);
        } else {
            alert("Por favor, complete todos los campos.");
        }
    }

    // Inicialización por defecto (apagado)
    toggleMotor(false);
    toggleSensor1(false);
    toggleSensor2(false);
    togglePasos(false);
</script>

</body>
</html>
