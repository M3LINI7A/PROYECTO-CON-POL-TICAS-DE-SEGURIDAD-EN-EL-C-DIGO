<?php
declare(strict_types=1);

require __DIR__ . '/../security/headers.php';
require __DIR__ . '/../security/session.php';
require __DIR__ . '/../security/errors.php';
require __DIR__ . '/../security/auth.php';
require __DIR__ . '/../security/response.php';

init_error_handling(__DIR__ . '/../security/logs/php-error.log');
secure_session_start();
logout();

json_response(['ok' => true]);
