<?php
declare(strict_types=1);

require __DIR__ . '/../security/headers.php';
require __DIR__ . '/../security/session.php';
require __DIR__ . '/../security/errors.php';
require __DIR__ . '/../security/auth.php';

init_error_handling(__DIR__ . '/../security/logs/php-error.log');
secure_session_start();
$user = current_user();
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>SPV</title>
  </head>
  <body>
    <h1>Bienvenido a SPV</h1>
    <?php if ($user): ?>
      <p>Autenticado como <strong><?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
      <ul>
        <li><a href="/api/me.php">/api/me.php</a> (datos de sesión)</li>
        <li><a href="/logout.php">/logout.php</a> (cerrar sesión)</li>
      </ul>
    <?php else: ?>
      <p><a href="/login.php">Iniciar sesión</a></p>
    <?php endif; ?>
  </body>
</html>
