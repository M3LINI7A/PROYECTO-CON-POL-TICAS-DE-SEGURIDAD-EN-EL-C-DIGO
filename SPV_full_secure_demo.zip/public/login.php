<?php
declare(strict_types=1);

require __DIR__ . '/../security/headers.php';
require __DIR__ . '/../security/session.php';
require __DIR__ . '/../security/errors.php';
require __DIR__ . '/../security/csrf.php';
require __DIR__ . '/../security/input.php';
require __DIR__ . '/../security/response.php';
require __DIR__ . '/../security/middleware.php';
require __DIR__ . '/../security/auth.php';

init_error_handling(__DIR__ . '/../security/logs/php-error.log');
secure_session_start();

$dsn = 'sqlite:' . dirname(__DIR__) . '/spv.sqlite';
$pdo = new PDO($dsn);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $csrf = csrf_field('form_login');
    echo '<!doctype html><html><head><meta charset="utf-8"><title>Login SPV</title></head><body>
    <h1>Login SPV</h1>
    <form method="POST">' . $csrf . '
      <label>Email <input type="email" name="email" required></label><br>
      <label>Contraseña <input type="password" name="password" required></label><br>
      <button type="submit">Ingresar</button>
    </form>
    <p>Ejemplo: admin@example.com / Admin123!</p>
    </body></html>';
    exit;
}

enforce_rate_limit(5, 60);
enforce_post_csrf('form_login');

$email = sanitize_email($_POST['email'] ?? '');
$pwd = $_POST['password'] ?? '';

if (!authenticate($pdo, $email, $pwd)) {
    json_error('Credenciales inválidas', 401);
}
json_response(['ok' => true, 'user' => current_user()]);
